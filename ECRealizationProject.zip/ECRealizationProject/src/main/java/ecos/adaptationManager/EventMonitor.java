package ecos.adaptationManager;

import ecos.contextManager.KBAdministrator;
import ecos.knowledgebase.EmergentConfiguration;
import ecos.knowledgebase.ECRepository;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;

import java.util.HashSet;
import java.util.Iterator;

public class EventMonitor extends Thread {
    KBAdministrator kbAdministrator = new KBAdministrator();
    ECRepository ecs = ECRepository.getInstance();
    OWLOntology ecOntology;
    EventHandler adapter = new EventHandler();
    public EventMonitor() {

    }

    public void run() {
        System.out.println("Monitoring process started....");
        while (true) {
            try {
                OWLOntology ecOntology = kbAdministrator.reloadLocalOntology();
                inferEvents(ecOntology, ecs);
                System.out.print(".");
                this.sleep(5000);
              //
            } catch (Exception e) {

                e.printStackTrace();
            }


        }


    }

    //ToDo: Seperate this code into two methods: the one which creates the events to be moved to a class called ReasoningEngine in the contextmanager package, the second will only detect the events and trigger the EventHandler to work.
    public void inferEvents(OWLOntology ecOntology, ECRepository ecs) throws Exception {

        Iterator ita = ecs.getAllActiveEmergentConfigurations().iterator();
        EmergentConfiguration ec;
        HashSet<String> devices = new HashSet<String>();
        while (ita.hasNext()) {
            ec = (EmergentConfiguration) ita.next();
            devices.addAll(ec.getConstituentDevicesAndCapabilities().keySet());
        }

        Integer deviceEnergyLevel;
        Iterator it = devices.iterator();
        OWLIndividual device;
        OWLObjectProperty locationProperty = kbAdministrator.getOWLObjectProperty("hasLocation");
        while (it.hasNext()) {
            device = (OWLIndividual) kbAdministrator.getOWLIndividual((String) it.next());
            EmergentConfiguration ecByDevice = ecs.getEmergentConfigurationByDevice(device);
            boolean deviceState = kbAdministrator.getDeviceState(ecOntology, device);
            boolean deviceStateEventExists = kbAdministrator.checkIfStateEventExist(ecOntology, device);
            if (deviceStateEventExists)
                continue;
            if (!deviceState && !deviceStateEventExists) {
                OWLIndividual event = kbAdministrator.createDeviceOffEvent(ecOntology, device);
//                handledDevices.add(device);
                System.out.println("An event to model that a thing has turned off is created!!");
                adapter.adaptECs(ecByDevice, event, ecOntology);
                continue;
            }
            String energyLevelString = kbAdministrator.getDeviceEnergyLevel(ecOntology, device);
            deviceEnergyLevel = new Integer(energyLevelString);

            if (ecByDevice != null) {
                String ecLocation = ecByDevice.getLocation().asOWLNamedIndividual().getIRI().getFragment();
                if(device.asOWLNamedIndividual().getIRI().getFragment().equals("rm"))
                    continue;
                OWLIndividual deviceLocationIndividual = kbAdministrator.getDeviceLocation(ecOntology, device, locationProperty);
                String deviceLocation = deviceLocationIndividual.asOWLNamedIndividual().getIRI().getFragment();
                if (!ecLocation.equals(deviceLocation)) {
                    OWLIndividual event =  kbAdministrator.createDeviceMovedEvent(ecOntology, device);
                    adapter.adaptECs(ecByDevice, event, ecOntology);
                    continue;

                }

            }
            if (deviceEnergyLevel < 15 && !kbAdministrator.checkIfEnergyEventExist(ecOntology, device)) {
                OWLIndividual event = kbAdministrator.createDeviceRunningOutOfEnergyEvent(ecOntology, device);
                System.out.println("An event to model that a thing is running out of energy created!!");
                adapter.adaptECs(ecByDevice, event, ecOntology);
                continue;

            }


        }


    }


}
