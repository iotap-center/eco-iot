package ecos.adaptationManager;

import ecos.contextManager.ECStatus;
import ecos.goalManager.translator.OWL2PDDLTranslator;


import ecos.knowledgebase.EmergentConfiguration;
import ecos.knowledgebase.ECRepository;
import ecos.goalManager.javaff.data.Plan;
import ecos.goalManager.javaff.ecos.planner.ECOSPlanner;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLOntology;

import java.io.File;

public class EventHandler {

    public void adaptECs(EmergentConfiguration ec, OWLIndividual event, OWLOntology ecOntology) {
        System.out.println("The adaptation process tries to adapt the EC in response of    " + event.asOWLNamedIndividual().getIRI().getFragment());
        try {
            OWL2PDDLTranslator tr = new OWL2PDDLTranslator();
            File domainFile = tr.generateDomainFile(ecOntology, null, null, 2);
            File problemFile = tr.generateProblemFile(ecOntology, null, null, 2);

            ECOSPlanner planner = new ECOSPlanner();
            Plan plan = planner.generatePlan(domainFile, problemFile);
            if (plan != null && plan.getActions().size() > 0) {

                EmergentConfiguration ecClone = (EmergentConfiguration) ec.clone();
                ecClone.setStatus(ECStatus.READY_FOR_EXECUTION);
                ecClone.setVersion(ec.getVersion() + 1);
                ecClone.setPreviousVersionEC(ec);
                ec.setStatus(ECStatus.ADAPTED);
                ECRepository.getInstance().addEmergentConfiguration(ecClone);
                System.out.println("The EC is adapted successfully to maintain the achivement of the user goal!");
            } else {
                System.out.println("The EC can't be adapted!");
                ec.setStatus(ECStatus.FAILED);

            }


        } catch (Exception e) {

            e.printStackTrace();
        }


    }


}
