package ecos.contextManager;


import javafx.util.Pair;
import org.semanticweb.HermiT.Configuration;
import org.semanticweb.HermiT.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.*;
import org.semanticweb.owlapi.search.Searcher;
import org.semanticweb.owlapi.util.*;
import uk.ac.manchester.cs.owl.owlapi.OWLNamedIndividualImpl;


import java.io.File;
import java.util.*;
import java.util.stream.Collectors;


public class KBAdministrator {

    public static IRI ontologyIRI = null;
    OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
    OWLDataFactory df = OWLManager.getOWLDataFactory();

    //public static final String onto_path2 = "/Users/ag7992/Documents/PhD_Work/ICSA_2018/ECRealizationProject/ecOntology.owl";
    public static final String iri = "ec/ECRealizationProject/ecOntology.owl#";
    //    public static final String onto_path = "#";

    public OWLOntology loadLocalOntology() {
        // Get hold of an ontology manager

        try {
            File file = new File("ecOntology.owl");
            // Now load the local copy
            OWLOntology localOntology = manager.loadOntologyFromOntologyDocument(file);
            return localOntology;
        } catch (Exception e) {
            e.printStackTrace();
            return null;

        }

    }

    public OWLAxiomChange associateObjectPropertyWithClass(OWLOntology o,
                                                           OWLObjectProperty property,
                                                           OWLClass refHolder,
                                                           OWLClass refTo) {
        OWLClassExpression hasSomeRefTo = df.getOWLObjectSomeValuesFrom(property, refTo);
        OWLSubClassOfAxiom ax = df.getOWLSubClassOfAxiom(refHolder, hasSomeRefTo);
        return new AddAxiom(o, ax);
    }

    public OWLIndividual createIndividual(String iri) {
        return createIndividual(convertStringToIRI(iri));
    }

    private OWLIndividual createIndividual(IRI iri) {
        return df.getOWLNamedIndividual(iri);
    }

    public OWLAxiomChange addObjectproperty(OWLOntology o,
                                            OWLIndividual ind1,
                                            OWLObjectProperty prop,
                                            OWLIndividual indv2) {

        return new AddAxiom(o, df.getOWLObjectPropertyAssertionAxiom(prop, ind1, indv2));
    }


    public OWLAxiomChange associateIndividualWithClass(OWLOntology o,
                                                       OWLClass clazz,
                                                       OWLIndividual individual) {
        return new AddAxiom(o, df.getOWLClassAssertionAxiom(clazz, individual));
    }


    public IRI convertStringToIRI(String ns) {
        return IRI.create(ns);
    }

    public OWLOntology createOntology(IRI iri) throws OWLOntologyCreationException {
        return manager.createOntology(iri);
    }

    public OWLOntology createOntology(String iri) throws OWLOntologyCreationException {
        return createOntology(convertStringToIRI(iri));
    }

    public OWLClass createClass(String iri) {
        return createClass(convertStringToIRI(iri));
    }

    public OWLClass createClass(IRI iri) {
        return df.getOWLClass(iri);

    }

    public OWLObjectProperty createObjectProperty(String iri) {
        return createObjectProperty(convertStringToIRI(iri));
    }

    public OWLObjectProperty createObjectProperty(IRI iri) {
        return df.getOWLObjectProperty(iri);

    }

    public OWLAxiomChange createSubclass(OWLOntology o, OWLClass subclass, OWLClass superclass) {
        return new AddAxiom(o, df.getOWLSubClassOfAxiom(subclass, superclass));

    }

    public void applyChange(OWLAxiomChange... axiom) {
        applyChanges(axiom);
    }

    private void applyChanges(OWLAxiomChange... axioms) {
        manager.applyChanges(Arrays.asList(axioms));

    }

    public OWLAxiomChange addDisjointClass(OWLOntology o, OWLClass a, OWLClass b) {
        OWLDisjointClassesAxiom expression = df.getOWLDisjointClassesAxiom(a, b);
        return new AddAxiom(o, expression);
    }

    public void printIndividualsByclass(OWLOntology ontology, OWLReasoner reasoner, String owlClass) {
        for (OWLClass c : ontology.classesInSignature().collect(Collectors.toSet())) {
            if (c.getIRI().getShortForm().equals(owlClass)) {
                NodeSet<OWLNamedIndividual> instances = reasoner.getInstances(c, false);
                System.out.println("Class : " + c.getIRI().getShortForm());
                for (OWLNamedIndividual i : instances.getFlattened()) {
                    System.out.println(i.getIRI().getShortForm());
                }
            }
        }
    }


    public OWLClass loadOWLClass(String className) {
        OWLClass owlclass = df.getOWLClass(iri + className);
        return owlclass;

    }


    public OWLNamedIndividual getOWLIndividual(String indvidualName) {

        OWLNamedIndividual owlNamedIndividual = df.getOWLNamedIndividual(iri + indvidualName);
        return owlNamedIndividual;
    }


    public void printAllInstances(OWLOntology owlOntology) {
        int i = 0;
        Set<OWLNamedIndividual> inds = owlOntology.individualsInSignature().collect(Collectors.toSet());
        for (OWLNamedIndividual ind : inds) {
            i++;
            System.out.println(ind.toStringID());
        }

        System.out.println("totla number of explored instances = " + i);

    }

    public OWLObjectProperty getOWLObjectProperty(String propertyName) {
        return df.getOWLObjectProperty(iri + propertyName);

    }


    private static void print(Node<OWLClass> parent, OWLReasoner reasoner, int depth) {
        // We don't want to print out the bottom node (containing owl:Nothing
        // and unsatisfiable classes) because this would appear as a leaf node
        // everywhere
        if (parent.isBottomNode()) {
            return;
        }
        // Print an indent to denote parent-child relationships
        printIndent(depth);
        // Now print the node (containing the child classes)
        printNode(parent);
        for (Node<OWLClass> child : reasoner.getSubClasses(
                parent.getRepresentativeElement(), true)) {
            // Recurse to do the children. Note that we don't have to worry
            // about cycles as there are non in the inferred class hierarchy
            // graph - a cycle gets collapsed into a single node since each
            // class in the cycle is equivalent.
            print(child, reasoner, depth + 1);
        }
    }

    private static void printIndent(int depth) {
        for (int i = 0; i < depth; i++) {
            System.out.print("    ");
        }
    }

    private static void printNode(Node<OWLClass> node) {
        DefaultPrefixManager pm = new DefaultPrefixManager(
                "http://owl.man.ac.uk/2005/07/sssw/people#");
        // Print out a node as a list of class names in curly brackets
        System.out.print("{");
        for (Iterator<OWLClass> it = node.entities().iterator(); it.hasNext(); ) {
            OWLClass cls = it.next();
            // User a prefix manager to provide a slightly nicer shorter name
            System.out.print(pm.getShortForm(cls));
            if (it.hasNext()) {
                System.out.print(" ");
            }
        }
        System.out.println("}");
    }


    public Reasoner getHermitReasoner(OWLOntology o) throws Exception {
        Configuration config = new Configuration();
        Reasoner reasoner = new Reasoner(config, o);
        return reasoner;

    }


    public OWLIndividual getUserLocation(OWLOntology ecOntology, OWLIndividual user, OWLObjectProperty locationProperty) {
        return Searcher.values(ecOntology.objectPropertyAssertionAxioms(user), locationProperty).findFirst().get();

    }

    public OWLIndividual getDeviceLocation(OWLOntology ecOntology, OWLIndividual device, OWLObjectProperty locationProperty) {

        return Searcher.values(ecOntology.objectPropertyAssertionAxioms(device), locationProperty).findFirst().get();

    }

    public Set<OWLNamedIndividual> getAvailableResourcesInLocation(OWLOntology ecOntology, OWLIndividual location, OWLObjectProperty locationProperty) throws Exception {

        Reasoner reasoner = this.getHermitReasoner(ecOntology);
        NodeSet<OWLNamedIndividual> resources = reasoner.getObjectPropertyValues(location.asOWLNamedIndividual(), reasoner.getInverseObjectProperties(locationProperty).getRepresentativeElement());

        Set<OWLNamedIndividual> onlyResourceSet = new HashSet<OWLNamedIndividual>();
        Set<OWLNamedIndividual> resourceSet = resources.entities().collect(Collectors.toSet());
        Iterator it = resourceSet.iterator();
        OWLClass ioTThingsClass = this.loadOWLClass("IoT-Thing");
        OWLNamedIndividual namedIndv = null;
        while (it.hasNext()) {
            namedIndv = (OWLNamedIndividual) it.next();
            if (reasoner.getTypes(namedIndv).containsEntity(ioTThingsClass)) {
                onlyResourceSet.add(namedIndv);
            }

        }

        return onlyResourceSet;
    }

    public void createManyIoTThings(OWLOntology o) throws Exception {
        OWLIndividual smartDevice = null;
        OWLIndividual precondition = null;
        OWLIndividual effect = null;
        OWLIndividual capability = null;
        OWLClass smartThing = this.loadOWLClass("SmartDevice");
        OWLClass preconditionClass = this.loadOWLClass("PreConditions");
        OWLClass effectClass = this.loadOWLClass("Effects");
        OWLIndividual room1 = this.getOWLIndividual("Room1");
        OWLObjectProperty hasLocation = this.getOWLObjectProperty("hasLocation");
        OWLObjectProperty hasPrecondition = this.getOWLObjectProperty("hasPrecondition");
        OWLObjectProperty hasEffect = this.getOWLObjectProperty("hasEffect");
        OWLObjectProperty hasCapility = this.getOWLObjectProperty("hasCapability");

        for (int i = 0; i < 500; i++) {
            smartDevice = this.createIndividual(iri + "smartObject" + i);
            capability = this.createIndividual(iri + "capability" + i);
            precondition = this.createIndividual(iri + "precondition" + i);
            effect = this.createIndividual(iri + "effect" + i);
            this.applyChange(
                    this.associateIndividualWithClass(o, smartThing, smartDevice),
                    this.associateIndividualWithClass(o, preconditionClass, precondition),
                    this.associateIndividualWithClass(o, effectClass, effect),
                    this.addObjectproperty(o, smartDevice, hasLocation, room1),
                    this.addObjectproperty(o, smartDevice, hasCapility, capability),
                    this.addObjectproperty(o, capability, hasEffect, effect),
                    this.addObjectproperty(o, capability, hasPrecondition, precondition));
            o.saveOntology();

        }
    }

    public HashMap<Pair, Pair> getDevicesCapabilitiesAndWorkingConditions(OWLOntology ecOntology, Set<OWLNamedIndividual> devices) {

        Iterator it = devices.iterator();
        OWLNamedIndividual device = null;
        HashMap<Pair, Pair> devicesCapabilities = new HashMap<Pair, Pair>();

        OWLObjectProperty hasCapability = this.getOWLObjectProperty("hasCapability");
        Iterator it2 = null;
        OWLIndividual capabilityPrecondition;
        OWLIndividual capabilityEffect;

        while (it.hasNext()) {
            device = (OWLNamedIndividual) it.next();
            Set<OWLIndividual> deviceCapabilitiesSet = this.getADeviceCapabilities(ecOntology, device);

            it2 = deviceCapabilitiesSet.iterator();
            while (it2.hasNext()) {
                OWLIndividual capability = (OWLIndividual) it2.next();
                Pair<OWLIndividual, OWLIndividual> deviceCapabilities = new Pair<OWLIndividual, OWLIndividual>(device, capability);
                Pair<OWLIndividual, OWLIndividual> capabilitiyPreconditionAndEffects = this.getCapabilityPreconditionAndEffects(ecOntology, capability);
                devicesCapabilities.put(deviceCapabilities, capabilitiyPreconditionAndEffects);
            }

        }
        return devicesCapabilities;
    }

    private Pair<OWLIndividual, OWLIndividual> getCapabilityPreconditionAndEffects(OWLOntology ecOntology, OWLIndividual capability) {


        //OWLObjectProperty hasEffect = this.getOWLObjectProperty("hasEffect");
        OWLIndividual precondition = this.getCapabilityPrecondition(ecOntology, capability);
        OWLIndividual effect = this.getCapabilityEffect(ecOntology, capability);

        return new Pair<OWLIndividual, OWLIndividual>(precondition, effect);


    }

    public OWLIndividual getCapabilityPrecondition(OWLOntology ecOntology, OWLIndividual capability) {
        OWLObjectProperty hasPrecondition = this.getOWLObjectProperty("hasPrecondition");

        Set<OWLIndividual> preconditionSet = Searcher.values(ecOntology.objectPropertyAssertionAxioms(capability), hasPrecondition).collect(Collectors.toSet());
        if (preconditionSet.iterator().hasNext())
            return preconditionSet.iterator().next();
        return null;


    }

    public OWLIndividual getCapabilityEffect(OWLOntology ecOntology, OWLIndividual capability) {
        OWLObjectProperty hasEffect = this.getOWLObjectProperty("hasEffect");

        Set<OWLIndividual> effectSet = Searcher.values(ecOntology.objectPropertyAssertionAxioms(capability), hasEffect).collect(Collectors.toSet());
        if (effectSet.iterator().hasNext())
            return effectSet.iterator().next();
        return null;

    }
    // used to reload ontology at runtime
    public OWLOntology reloadLocalOntology() {
        OWLOntologyManager manager2 = OWLManager.createOWLOntologyManager();
        OWLDataFactory df2 = OWLManager.getOWLDataFactory();
        File file = new File("ecOntology.owl");
        // Now load the local copy
        try {
            OWLOntology localOntology = manager2.loadOntologyFromOntologyDocument(file);
            return localOntology;
        } catch (Exception e) {
            e.printStackTrace();
            return null;

        }

    }

    public Set<OWLIndividual> getADeviceCapabilities(OWLOntology ecOntology, OWLNamedIndividual device) {
        OWLObjectProperty hasCapability = this.getOWLObjectProperty("hasCapability");
        return Searcher.values(ecOntology.objectPropertyAssertionAxioms(device), hasCapability).collect(Collectors.toSet());
    }



    public OWLDataProperty getOWLDataProperty(String propertyName) {

        return df.getOWLDataProperty(iri + propertyName);


    }

    public String getDeviceEnergyLevel(OWLOntology ecOntology, OWLIndividual device) throws Exception {
        OWLDataProperty hasEnergyLevel = this.getOWLDataProperty("hasEnergyLevel");
        if(!Searcher.values(ecOntology.dataPropertyAssertionAxioms(device), hasEnergyLevel).findFirst().isPresent())
            return "100";
        return Searcher.values(ecOntology.dataPropertyAssertionAxioms(device), hasEnergyLevel).findFirst().get().getLiteral();

    }


    public boolean getDeviceState(OWLOntology ecOntology, OWLIndividual device) throws Exception {
        if(((OWLNamedIndividualImpl) device).getIRI().getRemainder().get().equalsIgnoreCase("rm"))
            return true;
        OWLDataProperty hasState = this.getOWLDataProperty("hasState");
        return Searcher.values(ecOntology.dataPropertyAssertionAxioms(device), hasState).findFirst().get().parseBoolean();
    }

    public OWLIndividual createDeviceRunningOutOfEnergyEvent(OWLOntology ecOntology, OWLIndividual device) throws Exception {
        OWLClass thingRunningOutOfEnergyClass = this.loadOWLClass("IoTThingRunningOutOfEnergy");
        OWLIndividual eventIndividual = this.createIndividual("/ECRealizationProject/ecOntology.owl#" + device.asOWLNamedIndividual().getIRI().getFragment() + "IsRunningOutOfEnergy");
        //OWLIndividual eventIndividual = this.createIndividual("/ECRealizationProject/ecOntology.owl#SmartPhone1");
        OWLDataProperty hasDeviceFragment = this.getOWLDataProperty("hasDeviceFragment");
        OWLDataProperty hasTime = this.getOWLDataProperty("hasTime");
        this.applyChange(this.associateIndividualWithClass(ecOntology, thingRunningOutOfEnergyClass, eventIndividual));
        OWLDataPropertyAssertionAxiom dataPropertyDeviceFragmentAssertion = df
                .getOWLDataPropertyAssertionAxiom(hasDeviceFragment, eventIndividual, device.asOWLNamedIndividual().getIRI().getFragment());
        OWLDataPropertyAssertionAxiom dataPropertyAssertion = df
                .getOWLDataPropertyAssertionAxiom(hasTime, eventIndividual, new Date().toString());
        ecOntology.addAxiom(dataPropertyDeviceFragmentAssertion);
        ecOntology.addAxiom(dataPropertyAssertion);
        ecOntology.saveOntology();
        return eventIndividual;

    }


    public OWLIndividual createDeviceOffEvent(OWLOntology ecOntology, OWLIndividual device) throws Exception {
        OWLClass thingIsTurnedOffClass = this.loadOWLClass("IoTThingIsTurnedOff");
        OWLDataProperty hasDeviceFragment = this.getOWLDataProperty("hasDeviceFragment");
        OWLDataProperty hasTime = this.getOWLDataProperty("hasTime");
        OWLIndividual eventIndividual = this.createIndividual("/ECRealizationProject/ecOntology.owl#" + device.asOWLNamedIndividual().getIRI().getFragment() + "TurnedOff");
        this.applyChange(this.associateIndividualWithClass(ecOntology, thingIsTurnedOffClass, eventIndividual));
        OWLDataPropertyAssertionAxiom dataPropertyDeviceFragmentAssertion = df
                .getOWLDataPropertyAssertionAxiom(hasDeviceFragment, eventIndividual, device.asOWLNamedIndividual().getIRI().getFragment());
        OWLDataPropertyAssertionAxiom dataPropertyAssertion = df
                .getOWLDataPropertyAssertionAxiom(hasTime, eventIndividual, new Date().toString());
        ecOntology.addAxiom(dataPropertyDeviceFragmentAssertion);
        ecOntology.addAxiom(dataPropertyAssertion);
        ecOntology.saveOntology();
        return eventIndividual;
    }

    public OWLIndividual createDeviceMovedEvent(OWLOntology ecOntology, OWLIndividual device) throws Exception {
        OWLClass thingMovedOutClass = this.loadOWLClass("IoTThingMovedOut");
        OWLDataProperty hasDeviceFragment = this.getOWLDataProperty("hasDeviceFragment");
        OWLDataProperty hasTime = this.getOWLDataProperty("hasTime");
        OWLIndividual eventIndividual = this.createIndividual("/ECRealizationProject/ecOntology.owl#" + device.asOWLNamedIndividual().getIRI().getFragment() + "MovedOut");
        this.applyChange(this.associateIndividualWithClass(ecOntology, thingMovedOutClass, eventIndividual));
        OWLDataPropertyAssertionAxiom dataPropertyDeviceFragmentAssertion = df
                .getOWLDataPropertyAssertionAxiom(hasDeviceFragment, eventIndividual, device.asOWLNamedIndividual().getIRI().getFragment());
        OWLDataPropertyAssertionAxiom dataPropertyAssertion = df
                .getOWLDataPropertyAssertionAxiom(hasTime, eventIndividual, new Date().toString());
        ecOntology.addAxiom(dataPropertyDeviceFragmentAssertion);
        ecOntology.addAxiom(dataPropertyAssertion);
        ecOntology.saveOntology();
        return eventIndividual;
    }

    public boolean checkIfEnergyEventExist(OWLOntology ecOntology, OWLIndividual device) throws Exception {
        Reasoner reasoner = this.getHermitReasoner(ecOntology);
        OWLClass thingRunningOutOfEnergyClass = this.loadOWLClass("IoTThingRunningOutOfEnergy");
        NodeSet<OWLNamedIndividual> instances = reasoner.getInstances(thingRunningOutOfEnergyClass, false);
        String deviceName = device.asOWLNamedIndividual().getIRI().getFragment() + "runningOutOfEnergy";
        Set<OWLNamedIndividual> collect = instances.entities().collect(Collectors.toSet());
        Iterator it = collect.iterator();
        while (it.hasNext()) {

            OWLNamedIndividual namedIndividual = (OWLNamedIndividual) it.next();
            if (namedIndividual.getIRI().getFragment().equals(deviceName))
                return true;
        }
        return false;
    }

    public boolean checkIfStateEventExist(OWLOntology ecOntology, OWLIndividual device) throws Exception {
        Reasoner reasoner = this.getHermitReasoner(ecOntology);
        OWLClass thingIsTurnedOffClass = this.loadOWLClass("IoTThingIsTurnedOff");
        NodeSet<OWLNamedIndividual> instances = reasoner.getInstances(thingIsTurnedOffClass, false);
        String deviceName = device.asOWLNamedIndividual().getIRI().getFragment() + "TurnedOff";
        Set<OWLNamedIndividual> collect = instances.entities().collect(Collectors.toSet());
        Iterator it = collect.iterator();
        while (it.hasNext()) {
            OWLNamedIndividual namedIndividual = (OWLNamedIndividual) it.next();
            if (namedIndividual.getIRI().getFragment().equals(deviceName))
                return true;
        }
        return false;


    }
    public HashSet<String> getDevicesThatCanStreamPresentation(Set<Pair> availableDevices) {
        HashSet<String> devicesThatCanStreamPresentation = new HashSet<String>();
        Iterator it = availableDevices.iterator();
        Pair<OWLIndividual, OWLIndividual> pair;
        while (it.hasNext()){
            pair = (Pair<OWLIndividual, OWLIndividual>) it.next();
            String  deviceCapability = pair.getValue().asOWLNamedIndividual().getIRI().getFragment();
            if(deviceCapability.contains("streamPresentation")){
                devicesThatCanStreamPresentation.add(pair.getKey().asOWLNamedIndividual().getIRI().getFragment());
            }
        }
        return devicesThatCanStreamPresentation;
    }

    public HashSet<String> getDevicesThatCanIllustratePresentation(Set<Pair> availableDevices) {
        HashSet<String> devicesThatCanIllustratePresentation = new HashSet<String>();
        Iterator it = availableDevices.iterator();
        Pair<OWLIndividual, OWLIndividual> pair;
        while (it.hasNext()){
            pair = (Pair<OWLIndividual, OWLIndividual>) it.next();
            String  deviceCapability = pair.getValue().asOWLNamedIndividual().getIRI().getFragment();
            if(deviceCapability.contains("illustratePresentation")){
                devicesThatCanIllustratePresentation.add(pair.getKey().asOWLNamedIndividual().getIRI().getFragment());
            }
        }
        return devicesThatCanIllustratePresentation;
    }
}


