package ecos.contextManager;
public enum ECStatus {


    READY_FOR_EXECUTION ("READY_FOR_EXECUTION"),
    UNDER_EXECUTION("IN_EXECUTION"),
    ADAPTED("ADAPTED"),
    FAILED("FAILED"),
    ENACTED_SUCCESSFULLY("ENACTED_SUCCESSFULLY");
    private final String status;

    ECStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return this.status;
    }


}
