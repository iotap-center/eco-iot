package ecos.goalManager.javaff.test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import ecos.goalManager.javaff.data.GroundProblem;
import ecos.goalManager.javaff.data.TimeStampedPlan;
import ecos.goalManager.javaff.data.TotalOrderPlan;
import ecos.goalManager.javaff.data.UngroundProblem;
import ecos.goalManager.javaff.parser.PDDL21parser;
import ecos.goalManager.javaff.parser.ParseException;
import ecos.goalManager.javaff.parser.SolutionParser;
import ecos.goalManager.javaff.scheduling.STRIPSScheduler;
import ecos.goalManager.javaff.scheduling.SchedulingException;
import ecos.goalManager.javaff.scheduling.STRIPSScheduler.PlanValidationResult;

public class SchedulerTester
{

	public static void main(String[] args)
	{
		
		File domain = new File(args[0]); 
		File pfile = new File(args[1]);
		File soln = new File(args[2]);
		
		UngroundProblem uproblem = PDDL21parser.parseFiles(domain, pfile);
		GroundProblem gproblem = uproblem.ground();
		
		TotalOrderPlan top = null;
		try
		{
			top = SolutionParser.parse(uproblem, soln);

			STRIPSScheduler scheduler = new STRIPSScheduler(gproblem.getSTRIPSInitialState());
			TimeStampedPlan tsp = scheduler.schedule(top);
			PlanValidationResult result = scheduler.validate(tsp, gproblem.getSTRIPSInitialState(), gproblem.getGoal());
			if (result != PlanValidationResult.Valid)
				throw new SchedulingException("Scheduled plan did not validate");
			
			
			tsp.print(System.out);
			
			File scheduled = new File(args[3]);

			scheduled.delete();
			scheduled.createNewFile();
			
			FileOutputStream outputStream = new FileOutputStream(scheduled);
			PrintWriter printWriter = new PrintWriter(outputStream);
			tsp.print(printWriter);
			
			printWriter.close();
			outputStream.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		catch (SchedulingException e)
		{
			e.printStackTrace();
		}
	}
}
