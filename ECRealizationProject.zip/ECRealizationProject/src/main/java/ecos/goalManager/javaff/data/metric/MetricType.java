package ecos.goalManager.javaff.data.metric;

public enum MetricType
{
	//for the record, this is the incorrect way to spell both maximise and minimise.
	Maximize,
	Minimize,
}
