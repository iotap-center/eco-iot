package ecos.goalManager.javaff.landmark;

import java.util.Collection;

import ecos.goalManager.javaff.data.Fact;
import ecos.goalManager.javaff.data.strips.SingleLiteral;

public interface ILandmarkGenerator 
{
	public void generateLandmarks(java.util.Collection<SingleLiteral> goals);
	
	public void clearLandmarks();

    public Collection<Fact> getLandmarks();
    
    public LandmarkGraph getLandmarkGraph();
    
}
