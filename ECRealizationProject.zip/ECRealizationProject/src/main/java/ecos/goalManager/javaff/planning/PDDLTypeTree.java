package ecos.goalManager.javaff.planning;

public class PDDLTypeTree
{
	
}
