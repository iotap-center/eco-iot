package ecos.goalManager.javaff.ecos.planner;

import ecos.goalManager.javaff.JavaFF;
import ecos.goalManager.javaff.data.Plan;

import java.io.File;

public class ECOSPlanner {

    private static final String PRESENTATION_LOG_PATH = "./problems/presentation/";
    private static final String SOLUTION_FILE = "solution.txt";

    public Plan generatePlan(File domainFile, File problemFile) {
        try {
            File solutionFile = new File(PRESENTATION_LOG_PATH + SOLUTION_FILE);
            JavaFF ff = new JavaFF(domainFile, solutionFile);
            Plan plan = ff.plan(problemFile);
            System.out.println("----------------------------------------------------");
            return plan;
         //   plan.print(System.out);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }


}
