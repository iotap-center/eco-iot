package ecos.goalManager.javaff.data.strips;

import ecos.goalManager.javaff.data.Fact;

public interface STRIPSFact extends Fact
{

}
