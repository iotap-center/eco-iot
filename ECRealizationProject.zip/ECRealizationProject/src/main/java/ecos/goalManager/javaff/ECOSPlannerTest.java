package ecos.goalManager.javaff;
import ecos.goalManager.javaff.data.Plan;

import java.io.File;

public class ECOSPlannerTest {
    private static final String DRIVER_LOG_PATH = "./problems/presentation/";
    private static final String DOMAIN_FILE = "pdomain.pddl";
    private static final String SOLUTION_FILE = "solution.pddl";
    public static void main(String args[]){
        try {
            File domainFile = new File(DRIVER_LOG_PATH + DOMAIN_FILE);
            File solutionFile = new File(DRIVER_LOG_PATH + SOLUTION_FILE);
            File dir = new File(DRIVER_LOG_PATH);
            File[] directoryListing = dir.listFiles();
            if (directoryListing != null) {
                for (File problemFile : directoryListing) {
                    if (!problemFile.getName().endsWith(DOMAIN_FILE)) {
                        JavaFF ff = new JavaFF(domainFile, solutionFile);
                        Plan plan = ff.plan(problemFile);
                        plan.print(System.out);
                    }
                }
            }

        } catch (Exception e ){
            e.printStackTrace();
        }

    }

}
