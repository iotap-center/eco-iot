//
//  SuccessorSelector.java
//  JavaFF
//
//  Created by Andrew Coles on Thu Jan 31 2008.
//

package ecos.goalManager.javaff.search;

import ecos.goalManager.javaff.planning.State;
import java.util.Set;

public interface SuccessorSelector {

	State choose(Set toChooseFrom);

};
