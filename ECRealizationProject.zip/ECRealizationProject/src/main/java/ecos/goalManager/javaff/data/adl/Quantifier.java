package ecos.goalManager.javaff.data.adl;

import java.util.Map;
import java.util.Set;

import ecos.goalManager.javaff.data.Fact;
import ecos.goalManager.javaff.data.GroundFact;
import ecos.goalManager.javaff.data.strips.PDDLObject;
import ecos.goalManager.javaff.data.strips.Variable;

public interface Quantifier extends ADLFact
{
	public Set<PDDLObject> getQuantifiedObjects();
	
	public void setQuantifiedObjects(Set<PDDLObject> quantifiedObjects);

	public Fact getCondition();
	
	public void setCondition(Fact c);
	
	public Variable getVariable();
	
	public void setVariable(Variable v);
	
	public GroundFact ground(Map<Variable, PDDLObject> map);

	public Object clone();
}
