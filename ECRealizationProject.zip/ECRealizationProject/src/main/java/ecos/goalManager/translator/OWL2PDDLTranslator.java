package ecos.goalManager.translator;

import javafx.util.Pair;
import org.semanticweb.owlapi.model.OWLOntology;

import java.io.File;
import java.util.HashMap;

public class OWL2PDDLTranslator {

    private static final String PRESENTATION_LOG_PATH = "./problems/presentation/";
    private static final String DOMAIN_FILE = "pdomain1.pddl";
    private static final String DOMAIN_FILE2 = "pdomain2.pddl";
    private static final String PROBLEM_FILE = "pproblem1.pddl";
    private static final String PROBLEM_FILE2 = "pproblem2.pddl";


    public File generateDomainFile(OWLOntology ecOntology, HashMap<String, String> devicePreferencesMap, HashMap<Pair, Pair> availableCapabilities, int c) {

        File domainFile = null;
        if (c == 1) {
            domainFile = new File(PRESENTATION_LOG_PATH + DOMAIN_FILE);
        } else {
            domainFile = new File(PRESENTATION_LOG_PATH + DOMAIN_FILE2);
        }
        return domainFile;
    }

    public File generateProblemFile(OWLOntology ecOntology, HashMap<String, String> devicePreferencesMap, HashMap<Pair, Pair> availableCapabilities, int c) {

        File problemFile = null;
        if (c == 1) {
            problemFile = new File(PRESENTATION_LOG_PATH + PROBLEM_FILE);

        } else {
            problemFile = new File(PRESENTATION_LOG_PATH + PROBLEM_FILE2);

        }
        return problemFile;


    }


}
