package ecos.knowledgebase;

import ecos.contextManager.ECStatus;
import org.semanticweb.owlapi.model.OWLIndividual;

import java.util.HashSet;
import java.util.Iterator;

public class ECRepository {

    private static ecos.knowledgebase.ECRepository instance = null;


    static HashSet<EmergentConfiguration> ECRepository = new HashSet<EmergentConfiguration>();

    protected ECRepository() {
        // Exists only to defeat instantiation.
    }

    public static ecos.knowledgebase.ECRepository getInstance() {
        if (instance == null) {
            instance = new ECRepository();
        }
        return instance;
    }

    public HashSet<EmergentConfiguration> getAllActiveEmergentConfigurations() {
        HashSet<EmergentConfiguration> activeECs = new HashSet<EmergentConfiguration>();
        Iterator it = ECRepository.iterator();
        EmergentConfiguration ec = null;
        while (it.hasNext()) {
            ec = (EmergentConfiguration) it.next();
            if (ec.status.equals(ECStatus.UNDER_EXECUTION) || ec.status.equals(ECStatus.READY_FOR_EXECUTION))
                activeECs.add(ec);
        }

        return activeECs;


    }

    public EmergentConfiguration getEmergentConfigurationByDevice(OWLIndividual device) {
        Iterator it = instance.getAllActiveEmergentConfigurations().iterator();
        EmergentConfiguration ec;
        while (it.hasNext()) {
            ec = (EmergentConfiguration) it.next();
            if (ec.constituentDevicesAndCapabilities.keySet().contains(device.asOWLNamedIndividual().getIRI().getFragment()))
                ;
            return ec;
        }
        return null;


    }


    public void addEmergentConfiguration(EmergentConfiguration ec){

        this.ECRepository.add(ec);

    }
}
