package ecos.knowledgebase;

import ecos.contextManager.ECStatus;
import ecos.goalManager.javaff.data.Action;
import ecos.goalManager.javaff.data.Plan;
import org.semanticweb.owlapi.model.OWLIndividual;

import java.util.*;

public class EmergentConfiguration implements Cloneable{

    OWLIndividual user;

    HashMap<String, HashSet<String>> constituentDevicesAndCapabilities = new HashMap<String, HashSet<String>>();
    OWLIndividual location;

    public void setStatus(ECStatus status) {
        this.status = status;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public void setPreviousVersionEC(EmergentConfiguration previousVersionEC) {
        this.previousVersionEC = previousVersionEC;
    }

    // toDO: add goal later!
    ECStatus status;
    Plan plan;

    public ECStatus getStatus() {
        return status;
    }

    public Plan getPlan() {
        return plan;
    }

    public int getVersion() {
        return version;
    }

    public EmergentConfiguration getPreviousVersionEC() {
        return previousVersionEC;
    }

    int version = 0;
    EmergentConfiguration previousVersionEC = null;


    public OWLIndividual getUser() {
        return user;
    }

    public void setUser(OWLIndividual user) {
        this.user = user;
    }

    public HashMap<String, HashSet<String>> getConstituentDevicesAndCapabilities() {
        return constituentDevicesAndCapabilities;
    }

    public void setConstituentDevicesAndCapabilities(HashMap<String, HashSet<String>> constituentDevicesAndCapabilities) {
        this.constituentDevicesAndCapabilities = constituentDevicesAndCapabilities;
    }

    public OWLIndividual getLocation() {
        return location;
    }
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public void setLocation(OWLIndividual location) {
        this.location = location;
    }


    //ToDo: add the goal high description to the EC formation
    public static EmergentConfiguration formEC(Plan plan, OWLIndividual user, OWLIndividual location) {

        EmergentConfiguration ec = new EmergentConfiguration();
        ec.status = ECStatus.READY_FOR_EXECUTION;
        ec.setUser(user);
        ec.setLocation(location);
        ec.setPlan(plan);

        Iterator it = plan.getActions().iterator();
        StringTokenizer st;
        while (it.hasNext()) {
            Action action = (Action) it.next();
            st = new StringTokenizer(action.getName().toString(), "_");
            String capability = st.nextToken();
            String device = st.nextToken();
            // ToDO: refactor rm to TM (i.e., Thing manager instead of resource manager)
            if(device.equals("rm")){
                continue;
            }
            if (ec.constituentDevicesAndCapabilities.keySet().contains(device)) {
                ec.constituentDevicesAndCapabilities.get(device).add(capability);

            }
            else {
                HashSet<String> hs = new HashSet<String>();
                hs.add(capability);
                ec.constituentDevicesAndCapabilities.put(device,hs);
            }


        }
        ECRepository ecs = ECRepository.getInstance();
        ecs.addEmergentConfiguration(ec);
        System.out.println("An EC is formed to achieve the user goal \n");
        return ec;


    }


    public void setPlan(Plan plan) {
        this.plan = plan;
    }
}
