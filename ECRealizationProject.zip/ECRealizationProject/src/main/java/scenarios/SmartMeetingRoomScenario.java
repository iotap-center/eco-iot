package scenarios;


import utils.Util;
import ecos.adaptationManager.EventMonitor;
import ecos.contextManager.KBAdministrator;
import ecos.goalManager.translator.OWL2PDDLTranslator;
import ecos.knowledgebase.EmergentConfiguration;
import ecos.goalManager.javaff.data.Plan;
import ecos.goalManager.javaff.ecos.planner.ECOSPlanner;
import javafx.util.Pair;
import org.semanticweb.owlapi.model.*;


import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class SmartMeetingRoomScenario {
    KBAdministrator kbAdministrator = new KBAdministrator();
    static OWLOntology ecOntology = null;
    Util util = new Util();

    public void executePresentationScenario() throws Exception {
        long startTime = System.currentTimeMillis();

        OWLIndividual user = kbAdministrator.getOWLIndividual("Fahed");
        String userName = user.asOWLNamedIndividual().getIRI().getFragment();
        OWLObjectProperty locationProperty = kbAdministrator.getOWLObjectProperty("hasLocation");
        OWLIndividual userLocation = kbAdministrator.getUserLocation(ecOntology, user, locationProperty);
        Set<OWLNamedIndividual> availableResources = kbAdministrator.getAvailableResourcesInLocation(ecOntology, userLocation, locationProperty);

        // remember to substitute NULL values for capabilities that have no (preconditions or effects) in the pair creation method.
        HashMap<Pair, Pair> availableCapabilities = kbAdministrator.getDevicesCapabilitiesAndWorkingConditions(ecOntology, availableResources);
        HashSet<String> devicesThatCanStreamPresentation = kbAdministrator.getDevicesThatCanStreamPresentation(availableCapabilities.keySet());
        HashSet<String> devicesThatCanIllustratePresentation = kbAdministrator.getDevicesThatCanIllustratePresentation(availableCapabilities.keySet());

        //TODO: the user agent will replace the communication below, it is just presented to illustrate the prototype. Just press any key to continue the prototype
        //user selection of the source device (his smartphone in the example)
        String presentationSourceDevice = null;
        if (devicesThatCanStreamPresentation.size() == 1)
            presentationSourceDevice = util.getUserInput("There is only one device that can stream presentation which is:" + devicesThatCanStreamPresentation.toString() + "  would you like use it ? (Just press any key to continue the prototype execution)");
        else if (devicesThatCanStreamPresentation.size() > 1)
            presentationSourceDevice = util.getUserInput("Which of the following devices would you like to use to stream the presentation: " + devicesThatCanStreamPresentation.toString() + "(Just press any key to continue the prototype execution)");
        //System.out.println("Selected device is ......." + presentationSourceDevice);
        String presentationIllustratorDevice = util.getUserInput("Which of the following devices would you like to use to stream the presentation: " + devicesThatCanIllustratePresentation.toString() + " (Just press any key to continue the prototype execution)");
        //  System.out.println("Selected device is ......." + presentationIllustratorDevice);

        // device Preferences Map

        HashMap<String, String> devicePreferencesMap = new HashMap<String, String>();
        devicePreferencesMap.put("streamPresentation", presentationSourceDevice);
        devicePreferencesMap.put("illustratePresentation", presentationIllustratorDevice);
        // ToDo: implement the OWL2PDDLTranslator
        OWL2PDDLTranslator tr = new OWL2PDDLTranslator();
        File domainFile = tr.generateDomainFile(ecOntology, devicePreferencesMap, availableCapabilities, 1);
        File problemFile = tr.generateProblemFile(ecOntology, devicePreferencesMap, availableCapabilities, 1);

        // generate first plan
        ECOSPlanner planner = new ECOSPlanner();
        Plan plan = planner.generatePlan(domainFile, problemFile);
        if (plan != null && plan.getActions().size() > 0) {
            EmergentConfiguration ec = EmergentConfiguration.formEC(plan, user, userLocation);

        }


        // Send plan to enactment!

        long endTime = System.currentTimeMillis();
        System.out.println("Seconds take for execution is:" + (endTime - startTime) / 1000);
    }

    public void initiateContextManager(OWLOntology ecOntology) {
        EventMonitor em = new EventMonitor();
        em.start();
    }

    public static void main(String args[]) {
        try {

            SmartMeetingRoomScenario presentationScenario = new SmartMeetingRoomScenario();
            ecOntology = presentationScenario.LoadOntology();
            presentationScenario.initiateContextManager(ecOntology);

            presentationScenario.executePresentationScenario();
            //   System.out.println("Seconds take for execution is:" + (endTime - startTime) / 1000);
        } catch (Exception e) {
            e.printStackTrace();

        }

    }

    private OWLOntology LoadOntology() {
        return kbAdministrator.loadLocalOntology();

    }


}
