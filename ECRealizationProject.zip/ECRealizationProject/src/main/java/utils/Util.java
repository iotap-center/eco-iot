package utils;

import java.util.Scanner;

public class Util {

    public String getUserInput(String message) {
        Scanner reader = new Scanner(System.in);  // Reading from System.in

        System.out.println(message);
        String finalString = "";
        if (reader.hasNextLine()) {
            finalString = reader.nextLine();
        }
      //  reader.close();
        return finalString;

    }
}
