//import org.semanticweb.owlapi.apibinding.OWLManager;
//import org.semanticweb.owlapi.model.OWLAxiomChange;
//import org.semanticweb.owlapi.model.OWLClass;
//import org.semanticweb.owlapi.model.OWLOntology;
//import org.semanticweb.owlapi.model.OWLOntologyManager;
//
public class Test {

    public static void main(String[] args) {
//         OWLOntologyManager man = OWLManager.createOWLOntologyManager();
//
//        OntologyHelper oh = new OntologyHelper();
//        OWLOntology o = oh.createOntology("http://autumncode.com/ontologies/person.owl");
//        OWLClass person = oh.createClass("http://autumncode.com/ontologies/person.owl#Person");
//        OWLClass fireman = oh.createClass("http://autumncode.com/ontologies/person.owl#Fireman");
//        OWLAxiomChange axiom = oh.createSubclass(o, fireman, person);
//        oh.applyChange(axiom);







         }
}
