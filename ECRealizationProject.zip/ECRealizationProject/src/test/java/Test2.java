import fr.uga.pddl4j.encoding.CodedProblem;
import fr.uga.pddl4j.planners.ProblemFactory;
import fr.uga.pddl4j.planners.hsp.HSP;
import fr.uga.pddl4j.util.Plan;
import fr.uga.pddl4j.util.SequentialPlan;
import fr.uga.pddl4j.util.TemporalPlan;

import java.util.logging.ErrorManager;

public class Test2 {

    public static void main(String args[]) {
        try {
            // Get the domain and the problem paths from the command line
            String domain = args[0];
            String problem = args[1];

            // Create the problem factory
            final ProblemFactory factory = new ProblemFactory();

            // Parse the domain and the problem
            fr.uga.pddl4j.parser.ErrorManager errorManager = factory.parse(domain, problem);
            if (!errorManager.isEmpty()) {
                errorManager.printAll();
                System.exit(0);
            }

            // Encode and simplify the planning problem in a compact representation
            final CodedProblem pb = factory.encode();
            if (!pb.isSolvable()) {
                System.out.println("goal can be simplified to FALSE. "
                        + "no search will solve it");
                System.exit(0);
            }

            // Create the planner
            final HSP planner = new HSP();


            // Search for a solution plan
            final Plan plan = planner.search(pb);
            if (plan != null) {
                System.out.println(String.format("%nfound plan as follows:%n%n"));
                System.out.println(pb.toString(plan));
            } else {
                System.out.println(String.format("%nno plan found%n%n"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
